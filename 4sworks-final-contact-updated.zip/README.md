4SWORKS FULL-STACK WEBSITE
==========================

This project preserves the existing HTML/CSS/JS website and adds:
- Node.js + Express API
- PostgreSQL storage for customer enquiries
- Server-side validation and parameterized SQL
- Admin login with bcrypt password hashes and expiring JWTs
- Admin dashboard at /admin
- Enquiry status tracking: new / contacted / closed
- Security headers, login/enquiry rate limits, request size limits

REQUIREMENTS
------------
- Node.js 20 or newer
- PostgreSQL database (local install or managed provider)
- VS Code (optional, but convenient)

RUN LOCALLY ON WINDOWS
----------------------
1. Install Node.js LTS and PostgreSQL.
2. Open this extracted folder in VS Code.
3. Copy .env.example to a new file named .env.
   In PowerShell, you can run: Copy-Item .env.example .env
4. Create a PostgreSQL database named 4sworks. Example using psql:
   CREATE DATABASE "4sworks";
   If using a hosted database, copy its connection string into DATABASE_URL.
5. Edit .env:
   - DATABASE_URL with your real database connection string
   - PGSSL=true only if your provider requires TLS (managed providers often do)
   - JWT_SECRET: use a unique random secret of at least 32 characters
   - ADMIN_EMAIL: the email you will use for the admin account
6. In the VS Code terminal run:
   npm install
   npm run admin:create
   Enter a strong password of at least 12 characters when prompted.
7. Start the website:
   npm run dev
8. Open http://localhost:3000
   Admin dashboard: http://localhost:3000/admin
   API health check: http://localhost:3000/api/health

The server creates the database tables on startup. The database itself must already exist.

IMPORTANT FRONTEND NOTE
-----------------------
The enquiry form now POSTs to /api/enquiries. Serve the public folder through this Express app;
do not open index.html with file:// or run only Live Server, because that bypasses the API.

SECURITY
--------
- Never commit .env to GitHub or share your DB password/JWT secret.
- Use a unique, long JWT_SECRET in production.
- Use HTTPS in production.
- Give the database user only the permissions needed for this app.
- Keep Node dependencies updated and back up the database.
- Admin JWT is held in browser memory, not localStorage; re-login after a page refresh.
- Configure provider TLS correctly. Do not disable certificate checks in production.
- Basic rate limits are included, but add a CAPTCHA or managed bot protection if spam becomes an issue.
- This starter does not send email/SMS notifications. Admin must check /admin for new enquiries.
- Do not put secrets in frontend JavaScript.
- Admin dashboard uses noindex metadata, but this is not a security boundary; login is the protection.

DEPLOYMENT OVERVIEW
-------------------
Recommended simple deployment:
A) PostgreSQL: create a database on a managed PostgreSQL host. Copy its connection string.
B) App host: deploy this repository to a Node.js host that supports a persistent Express server
   (for example Render or Railway). Set build command `npm install` and start command `npm start`.
C) Set environment variables in the host dashboard (not in source control):
   NODE_ENV=production
   DATABASE_URL=<managed PostgreSQL connection string>
   PGSSL=true or false as required by the provider
   JWT_SECRET=<unique random secret>
   JWT_EXPIRES_IN=2h
   ADMIN_EMAIL=<your admin email>
   PORT is usually set by the host automatically.
D) Deploy, open /api/health, create the admin from a secure shell/console using
   `npm run admin:create` (or run it once locally with the production DATABASE_URL kept private),
   then test the public form and /admin.
E) Connect your custom domain in the hosting dashboard and complete its DNS instructions.
F) Use HTTPS and verify database connectivity before publishing your domain.

Do not deploy the API as a static-only site on Vercel. This project expects a long-running Express
server; use a Node-capable service, or intentionally adapt it to serverless functions first.

API ROUTES
----------
POST /api/enquiries
  JSON: { "name": "A Name", "phone": "+91 9876543210", "service": "Plumbing", "message": "Tap leak" }
  Public route; validated and rate-limited.

POST /api/admin/login
  JSON: { "email": "admin@example.com", "password": "..." }
  Returns a short-lived JWT.

GET /api/admin/enquiries
  Optional ?status=new|contacted|closed
  Requires Authorization: Bearer <token>

PATCH /api/admin/enquiries/:id/status
  JSON: { "status": "contacted" }
  Requires Authorization: Bearer <token>

GET /api/health
  Basic app/database health check.

This is a starter implementation, not a substitute for a production security review.


WHATSAPP ENQUIRIES
------------------
The public enquiry form first saves the enquiry to PostgreSQL, then opens WhatsApp
with a pre-filled message addressed to 4Sworks (+91 94954 66976). The customer
must press Send in WhatsApp. This is not automatic background delivery.
The number is configured in public/script.js as BUSINESS_WHATSAPP.


BUSINESS CONTACT DETAILS
------------------------
Phone/WhatsApp: +91 9497464976
Email: 4sworkss@gmail.com
